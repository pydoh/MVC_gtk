# -*- coding: utf-8 -*-


class MainModel(object):

    # Observable properties
    somevalue = 0
    __observables__ = ("somevalue",)

    def __init__(self):
        #Model.__init__(self)
        return

    def thisMainModelfunc(self):
        # sandbox-0.3.0 Get funclist
        pass

    def thatMainModelfunc(self):
        # sandbox-0.3.0 Get funclist
        pass

    pass  # end of class MainModel
